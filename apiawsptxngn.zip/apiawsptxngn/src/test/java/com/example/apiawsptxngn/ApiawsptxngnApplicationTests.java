package com.example.apiawsptxngn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiawsptxngnApplicationTests {

	@Test
	void contextLoads() {
	}

}
