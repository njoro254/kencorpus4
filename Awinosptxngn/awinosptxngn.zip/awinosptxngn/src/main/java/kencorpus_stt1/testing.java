/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kencorpus_stt1;

import java.io.File;
import java.util.*;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.*;
import java.io.IOException;
import org.aspectj.internal.lang.annotation.ajcDeclareAnnotation;
//import edu.cmu.sphinx.alignment.tokenizer;
import edu.cmu.sphinx.api.Configuration;
import edu.cmu.sphinx.api.SpeechResult;
import edu.cmu.sphinx.api.StreamSpeechRecognizer;
import java.util.Arrays;

import java.awt.event.*;  
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.JFileChooser;

/**
 *
 * @author Ebbie
 */
public class testing {
    public static void main(String[] args) throws Exception 
    {

            JFrame f=new JFrame("Transcribe Audio File");  
            
            final JTextField tf5=new JTextField();  
            tf5.setBounds(50,50, 500,500);
            
            final JTextArea tf=new JTextArea(); 
            tf.setBounds(5,100, 2000,100);
            
            JLabel l1=new JLabel();  
            l1.setBounds(60,10, 150,150); 
            l1.setText("Actual transcription ");  
    
            
            JTextArea tf2=new JTextArea(); 
            tf2.setBounds(5,300, 2000,100);
            
            JLabel l2=new JLabel();  
            l2.setBounds(50,200, 150,150);
            l2.setText("Result transcription ");
            
            JButton b=new JButton("Select File");  
            b.setBounds(60,20,120,30);
            JButton btnTranscribe=new JButton("Transcribe:");  
            btnTranscribe.setBounds(65,20,120,30);
            b.addActionListener(new ActionListener(){  
            
            public void actionPerformed(ActionEvent e)
            {  
                try {
                    File file = new File("src//main//java//language_model//actual transcripts.txt");
                    
                    Scanner scanner = new Scanner(file);
                    String clientID = "test_19";
                    int lineNum = 0;
                    while (scanner.hasNextLine()) {
                        String line = scanner.nextLine();
                        lineNum++;
                        if(line.toLowerCase().contains(clientID.toLowerCase())) { 
                            
                            String str2 = Files.readAllLines(Paths.get("src//main//java/language_model//actual transcripts.txt")).get(lineNum-1);
                            tf.setText(str2);
                        }
                    }
                    
                    

                    String str1 = Files.readAllLines(Paths.get("src//main//java//language_model//test_19.txt")).get(0);
                    
                    Configuration configuration = new Configuration();
                    
                    configuration.setAcousticModelPath("src//main//java//acoustic");
                    configuration.setDictionaryPath("src//main//java//language_model//dictionary.dic");
                    configuration.setLanguageModelPath("src//main//java//language_model//language.lm");
                    
                    StreamSpeechRecognizer recognizer = new StreamSpeechRecognizer(configuration);
                    
                    //InputStream stream = new FileInputStream(new File("F:\\Ebbieapp\\kencorpus_stt1\\src\\audio\\test_19.wav"));
                   //  System.out.println(" output..."+fetch_file_extension(str1));
                    InputStream stream = new FileInputStream(new File(fetch_file_extension(str1)));
                
                    stream.skip(44);
                    
                    recognizer.startRecognition(stream);
                    SpeechResult result;
                    
                    while ((result = recognizer.getResult()) != null)
                    {
                        //tf1.setText(str1);
                        tf2.setText(result.getHypothesis());
                        
//                    String str2 = result.getHypothesis();
//                    System.out.println("Original trancript: "+str1);
//                    System.out.println("Result transcript: " +result.getHypothesis());
//                    System.out.format("WER :%s\n", compute_Levenshtein_distance(str1, str2));

                    }
                    recognizer.stopRecognition();
                } catch (IOException ex) {
                    Logger.getLogger(testing.class.getName()).log(Level.SEVERE, null, ex);
                }
               
                    }  
                });  
            f.add(b); f.add(l1);f.add(l2);f.add(tf2);
            f.add(tf);
            f.setSize(400,400);  
            f.setLayout(null);  
            f.setVisible(true);   
          
                
    }
    
    //Levenshtein_distance
    static String fetch_file_extension(String str1)
    {
            JFrame f=new JFrame("Select Audio File");  
            final JTextField tf=new JTextField();  
            tf.setBounds(50,50, 150,20);
            final JTextField tf1=new JTextField(); 
            tf1.setBounds(50,50, 150,20);
            
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
            int result = fileChooser.showOpenDialog(f);
            if (result == JFileChooser.APPROVE_OPTION) {
                // user selects a file
                File selectedFile = fileChooser.getSelectedFile();
                fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
                str1 = selectedFile.getAbsolutePath();
                System.out.println(selectedFile.getAbsolutePath()+" file...");
                        
                
            }    
        return str1;
        
    }
   

   
    
    
}

    

