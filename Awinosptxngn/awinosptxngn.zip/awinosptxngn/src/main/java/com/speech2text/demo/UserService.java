/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.speech2text.demo;

import com.fasterxml.jackson.databind.ObjectMapper;
import edu.cmu.sphinx.api.Configuration;
import edu.cmu.sphinx.api.SpeechResult;
import edu.cmu.sphinx.api.StreamSpeechRecognizer;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
//import org.apache.commons.io.FileUtils
import java.net.URL;
import java.net.URLConnection;
import java.util.logging.Level;
import java.util.logging.Logger;
import kencorpus_stt1.testing;

/**
 *
 * @author Jadala 2022
 * @author Awino 2021
 */
@Service
public class UserService {
    
    public User getJson(String user, List<MultipartFile> file)
    {
        User userJson;
        
        userJson=new User();
        try {
            ObjectMapper objectMapper=new ObjectMapper();
            userJson=objectMapper.readValue(user,User.class);
            System.out.print(userJson.toString());
            
            
        } catch (IOException err) {
            System.out.printf("Error Mapping User", err.toString());
        }
        
        int fileCount=file.size();
        userJson.setCount(fileCount);
         
        //
        com.speech2text.demo.UserFile usrFile;
        usrFile=new com.speech2text.demo.UserFile();
      
       MultipartFile fl;
       fl=file.get(0);
         usrFile.setFilepath("http://localhost:5000/api/v2/showmetadatadownloadfile/Swahili/Swahili_RP2/00_test_19.wav");
       System.out.print(fl.getOriginalFilename()+" the original");
       userJson.setPlace(usrFile.getFilepath());
        //  try {
        //   fileservice(usrFile, userJson);
       //     } catch (IOException ex) {
          //      Logger.getLogger(UserService.class.getName()).log(Level.SEVERE, null, ex);
         //   }
    return userJson;
    }
    public User getuserJson(String user)
    {
        User userJson;
        userJson=new User();
        try {
            ObjectMapper objectMapper=new ObjectMapper();
            userJson=objectMapper.readValue(user,User.class);
            
            
        } catch (IOException err) {
            System.out.printf("Error analyzing User", err.toString());
        }
    
    return userJson;
    }

    User getuserJson(User newUser) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    UserFile fileservice(String userfile) throws IOException
    {
        UserFile usrFile;
        usrFile=new UserFile();
        try {
            ObjectMapper objmap=new ObjectMapper();
            usrFile=objmap.readValue(userfile, UserFile.class);
        } catch (IOException er) {
            System.err.println("failure mapping "+userfile);
        }
//F:\kencorpusweb\langcorpus\flasktables\raw\Swahili\POCAPIfiles\audio
        //http://localhost:5000/api/v2/showmetadatadownloadfile/Swahili/Swahili_RP2/00_test_19.wav
        /*try {
            URL url = new URL(userfile.getFilepath());//the set is done through the api as a json object 2022 Feb 12 
            URLConnection connection = url.openConnection();
            FileOutputStream fos;
            try (InputStream in = connection.getInputStream()) {
                fos = new FileOutputStream(new File("downloaded.wav"));
                byte[] buf = new byte[512];
                while (true) {
                    int len = in.read(buf);
                    if (len == -1) {
                        break;
                    }
                    fos.write(buf, 0, len);
                    
                }   System.err.println(userfile.getFilepath());
                System.out.println("http://localhost:5000/api/v2/showmetadatadownloadfile/Swahili/Swahili_RP2/00_test_19.wav");
            }
            fos.flush();
            fos.close();
        } catch (MalformedURLException ex) {
            Logger.getLogger(UserService.class.getName()).log(Level.SEVERE, null, ex);
        }
*/
       // usrFile.setFilepath(userfile);
        System.out.println(usrFile.getFilepath()+"..user service call");
        try{
         Configuration configuration = new Configuration();
                     
                    configuration.setAcousticModelPath("src//main//java//acoustic");
                    configuration.setDictionaryPath("src//main//java//language_model//dictionary.dic");
                    configuration.setLanguageModelPath("src//main//java//language_model//language.lm");
                    
                    StreamSpeechRecognizer recognizer = new StreamSpeechRecognizer(configuration);
                    /////////////
                    //Input from web url/////
                 //   try{
                    URL url = new URL(usrFile.getFilepath());//the set is done through the api as a json object 2022 Feb 12 
                URLConnection connection = url.openConnection();
                   /// }catch( )
                FileOutputStream fos;
                 InputStream stream = connection.getInputStream();
                   // }
                    ///////////
                    //input the parameter from api inputs..
                    //InputStream stream = new FileInputStream(new File("F:\\Ebbieapp\\kencorpus_stt1\\src\\audio\\test_19.wav"));
                   //  System.out.println(" output..."+fetch_file_extension(str1));
                    //InputStream stream = new FileInputStream(new File(fetch_file_extension(str1)));
                
                    stream.skip(44);
                    
                    recognizer.startRecognition(stream);
                    SpeechResult result;
                    
                    while ((result = recognizer.getResult()) != null)
                    {
                        //tf1.setText(str1);
                       // tf2.setText(result.getHypothesis());
                        usrFile.setFileTextOutput(result.getHypothesis());
                        
//                    String str2 = result.getHypothesis();
//                    System.out.println("Original trancript: "+str1);
//                    System.out.println("Result transcript: " +result.getHypothesis());
//                    System.out.format("WER :%s\n", compute_Levenshtein_distance(str1, str2));

                    }
                    recognizer.stopRecognition();
                } catch (IOException ex) {
                    Logger.getLogger(testing.class.getName()).log(Level.SEVERE, null, ex);
                }
               
           return usrFile;           
    //return String.format("Translated Successfully %s!", name);
    }

    User getJsonapi(String user, MultipartFile file) {
          User userJson;
        
        userJson=new User();
        try {
            ObjectMapper objectMapper=new ObjectMapper();
            userJson=objectMapper.readValue(user,User.class);
            System.out.print(userJson.toString());
            
            
        } catch (IOException err) {
            System.out.printf("Error Mapping User", err.toString());
        }
        
       // int fileCount=file.size();
        userJson.setCount(1);
         
        //
        com.speech2text.demo.UserFile usrFile;
        usrFile=new com.speech2text.demo.UserFile();
      
       MultipartFile fl;
       fl=file;
      String filename=file.getOriginalFilename();
         usrFile.setFilepath("http://localhost:5000/api/v2/showmetadatadownloadfile/Swahili/Swahili_RP2/00_test_19.wav");
       System.out.print(fl.getOriginalFilename()+" the original");
       userJson.setPlace(usrFile.getFilepath());
        //  try {
        //   fileservice(usrFile, userJson);
       //     } catch (IOException ex) {
          //      Logger.getLogger(UserService.class.getName()).log(Level.SEVERE, null, ex);
         //   }
    return userJson;
       // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
