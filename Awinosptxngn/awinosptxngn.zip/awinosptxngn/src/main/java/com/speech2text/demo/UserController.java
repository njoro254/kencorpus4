/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.speech2text.demo;

import java.io.IOException;
import java.rmi.ServerException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author Jadala
 */
@RestController
public class UserController {
    
    @Autowired
    UserService userService;
   @PostMapping (value="/awsptxngn/swa/audio/upload",consumes={MediaType.APPLICATION_JSON_VALUE,
    MediaType.MULTIPART_FORM_DATA_VALUE})
    public User upload(@RequestPart("user") String user,@RequestPart("file") List<MultipartFile> file)
    {
         //var hi;
        // hi=7;
       User userJson=userService.getJson(user,file);
        
   return userJson;
    }
   
    ////////////////////
       @PostMapping (value="/awsptxngn/swa/audio/uploadapi",consumes={MediaType.APPLICATION_JSON_VALUE,
    MediaType.MULTIPART_FORM_DATA_VALUE})
    public User apiupload(@RequestPart("user") String user,@RequestPart("file") MultipartFile file)
    {
       User userJson=userService.getJsonapi(user,file);
        
   return userJson;
    }
    //////////////////
      @Autowired
    UserService servicerecordusr;
       @PostMapping (value="/awsptxngn/post/userfile",consumes={MediaType.APPLICATION_JSON_VALUE,
    MediaType.MULTIPART_FORM_DATA_VALUE})
       //,	produces = MediaType.APPLICATION_JSON_VALUE
    public UserFile postuserfile(@RequestPart("data") String userfile) throws IOException
    {
       // User userjson=new User();
       // UserFile userfileJson=new UserFile();
        //userfileJson.setFilepath("testing");
        //userfileJson.setFileTextOutput("yadaa");
        System.out.println(userfile);
        
        //try {
         UserFile   userfileJson = userService.fileservice(userfile);
            System.out.println("trying posting userfile..conrtoller level.");
      //  } catch (IOException ex) {
           // Logger.getLogger(UserController.class.getName()).log(Level.SEVERE, null, ex);
             System.out.print("working it out.. posting usr file...");
      //  }
           //userfileJson.setFilepath("testing");
        //userfileJson.setFileTextOutput("yadaa");
   
        System.out.print("User file test controller level "+userfileJson.getFilepath());
    return userfileJson;
    }
    //////////////////
     @GetMapping("/sasama")
public String hello(@RequestParam(value = "name", defaultValue = "World") String name) {
return String.format("Vipi %s!", name);
     }//
@PostMapping(path = "/users", 
        consumes = MediaType.APPLICATION_JSON_VALUE, 
        produces = MediaType.APPLICATION_JSON_VALUE)
public ResponseEntity<User> create(@RequestBody User newUser) {
    User user = userService.getuserJson(newUser);
    if (user == null) {
        try {
          // System.out.print ServerException();
        }
        catch (Exception err) {
            System.out.printf("Error Mapping User", err.toString());
        }
    } 
      return new ResponseEntity<>(user, HttpStatus.CREATED);
}

    @PostMapping ("/postaudiolistitem")
public String postconvert(@RequestParam(value = "name", defaultValue = "World") String name) {
return String.format("Vipi %s!", name);// 
     }//http://localhost:8080/postaudiolistitem
    
    
}
