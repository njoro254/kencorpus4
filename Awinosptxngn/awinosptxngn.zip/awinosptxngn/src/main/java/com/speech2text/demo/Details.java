/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.speech2text.demo;

import java.util.ArrayList;

/**
 *
 * @author Jadala
 */
public class Details {
     // Creating an object of ArrayList
    static ArrayList<Details> Data
        = new ArrayList<Details>();
    int number;
    String name;
    Details(int number, String name)
    {
        // This keyword refers to parent instance itself
        this.number = number;
        this.name = name;
    }
    
}
