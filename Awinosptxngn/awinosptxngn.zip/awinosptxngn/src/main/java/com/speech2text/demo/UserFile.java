/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.speech2text.demo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author Jadala
 */
//@Entity
@JsonIgnoreProperties(ignoreUnknown=true)
//@Getter
//@Setter
//@NoArgsConstructor
public class UserFile {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	private String name;
	private Date created = new Date();
	private String fileTextOutput;
        private String filepath;
        
	private String contentId;
	private long contentLength;
	private String contentMimeType = "text/plain";

    public String getFilepath() {
        return filepath;
    }

    public void setFilepath(String filepath) {
        this.filepath = filepath;
    }
    
        //This api should log usage by other apps either data.kencorpus.co.ke or 3rd party client.

    public String getFileTextOutput() {
        return fileTextOutput;
    }

    public void setFileTextOutput(String fileTextOutput) {
        this.fileTextOutput = fileTextOutput;
    }
}
