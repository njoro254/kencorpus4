package com.speech2text.demo;

import static com.speech2text.demo.Details.Data;
import com.speech2text.demo.property.FileStorageProperties;
import edu.cmu.sphinx.api.Configuration;
import edu.cmu.sphinx.api.SpeechResult;
import edu.cmu.sphinx.api.StreamSpeechRecognizer;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.net.URL;
import java.net.URLConnection;
import kencorpus_stt1.testing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@EnableConfigurationProperties({
        FileStorageProperties.class
})
@RestController
public class DemoApplication {

	public static void main(String[] args) {
            System.out.println("Ni kubaya");
		SpringApplication.run(DemoApplication.class, args);
	}
        /////////
  
        ////////////
        @GetMapping("/sasa")
public String hello(@RequestParam(value = "name", defaultValue = "World") String name) {
return String.format("Hello %s!", name);
     }

@GetMapping("/sptxawngn")
public String annotate(@RequestParam(value = "name", defaultValue = "World") String name) {
try {
                    File file = new File("src//main//java//language_model//actual transcripts.txt");
                   
                    Scanner scanner = new Scanner(file);
                    String clientID = "test_19";
                    int lineNum = 0;
                    while (scanner.hasNextLine()) {
                        String line = scanner.nextLine();
                        lineNum++;
                        if(line.toLowerCase().contains(clientID.toLowerCase())) { 
                            
                            String str2 = Files.readAllLines(Paths.get("src//main//java/language_model//actual transcripts.txt")).get(lineNum-1);
                            //tf.setText(str2);
                            name=str2;
                        }
                    }
                    
                    
                           //Input parameter one from api inputs.. 
                    String str1 = Files.readAllLines(Paths.get("src//main//java//language_model//test_19.txt")).get(0);
                    
                    Configuration configuration = new Configuration();
                    //How to generate and update these file contents. 2022 Feb 19 16:30H
                    configuration.setAcousticModelPath("src//main//java//acoustic");
                    configuration.setDictionaryPath("src//main//java//language_model//dictionary.dic");
                    configuration.setLanguageModelPath("src//main//java//language_model//language.lm");
                    
                    StreamSpeechRecognizer recognizer = new StreamSpeechRecognizer(configuration);
                    /////////////
                    //User Input from web url///// feeding it from developer api/////  
                    
                    URL url = new URL("http://localhost:5000/api/v2/showmetadatadownloadfile/Swahili/Swahili_RP2/00_test_19.wav");//the set is done through the api as a json object 2022 Feb 12 
                URLConnection connection = url.openConnection();
                FileOutputStream fos;
                 InputStream stream = connection.getInputStream();
                    ///////////User Input from file path or post from form input 
                    //input the parameter from api inputs..
                    //InputStream stream = new FileInputStream(new File("F:\\Ebbieapp\\kencorpus_stt1\\src\\audio\\test_19.wav"));
                   //  System.out.println(" output..."+fetch_file_extension(str1));
                    //InputStream stream = new FileInputStream(new File(fetch_file_extension(str1)));
                
                    stream.skip(44);
                    
                    recognizer.startRecognition(stream);
                    SpeechResult result;
                    
                    while ((result = recognizer.getResult()) != null)
                    {
                        //tf1.setText(str1);
                       // tf2.setText(result.getHypothesis());
                        name=" test "+str1+"\n vs \n result..."+result.getHypothesis();
                        
//                    String str2 = result.getHypothesis();
//                    System.out.println("Original trancript: "+str1);
//                    System.out.println("Result transcript: " +result.getHypothesis());
//                    System.out.format("WER :%s\n", compute_Levenshtein_distance(str1, str2));

                    }
                    recognizer.stopRecognition();
                } catch (IOException ex) {
                    Logger.getLogger(testing.class.getName()).log(Level.SEVERE, null, ex);
                }
               
                      
    return String.format("Translated Successfully %s!", name);
     }
///////
	// Single item
	
	@GetMapping("/employees/{id}")
	public Long one(@PathVariable Long id) {
		
		return id;
			
	}
@PostMapping("/njoroge")
public String postemployee(@RequestBody String data)
{
return data;
        }

@DeleteMapping("/remove/{id}")
@ResponseStatus(HttpStatus.OK)


public void delete(@PathVariable("id") Long id) {
//service.deleteById(id);
System.out.println("deleting...");
}

     @PostMapping("/postbody")
     public Person postBody(@RequestBody Person person){
      // public ResponseEntity<Person> postBody(@RequestBody Person person) {
       // Person persistedPerson = personService.save(person);
       // return ResponseEntity
          //  .created(URI
          //           .create(String.format("/persons/%s", person.getFirstName())))
         //   .body(persistedPerson);
         return person;
    }
        @PostMapping("/EnterDetails")

    String insert(@RequestBody Details ob)
    {
        // Storing the incoming data in the list
       Data.add(new Details(ob.number, ob.name));

        // Iterating using foreach loop
        for (Details obd : Data) {
           System.out.println(obd.name + " " + obd.number);
       }
        return "Data "+ob.number +" Inserted";
    }
	//Employee newEmployee(@RequestBody Employee newEmployee) {
            //return newEmployee.getName()+" "+newEmployee.getRole() +" "+newEmployee.getId();
		//return repository.save(newEmployee);
         //       return newEmployee;
	//}//
}
